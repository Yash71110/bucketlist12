import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";

/**
 * Supabase client for Server Components and Server Actions.
 *
 * Reads/writes auth cookies through Next.js's `cookies()` API. Writing only
 * actually succeeds when called from a Server Action or Route Handler —
 * Server Components can read cookies but cannot set them, which is fine
 * here because our middleware (see middleware.ts) is responsible for
 * refreshing the session on every request.
 */
export async function createClient() {
  const cookieStore = await cookies();

  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return cookieStore.getAll();
        },
        setAll(cookiesToSet) {
          try {
            cookiesToSet.forEach(({ name, value, options }) =>
              cookieStore.set(name, value, options)
            );
          } catch {
            // Called from a Server Component during rendering — safe to
            // ignore since middleware refreshes the session on requests.
          }
        },
      },
    }
  );
}
